#!/usr/bin/env node
// toongine CLI — ToonGine v1.6.0
// One command: npx toongine init — builds everything

const fs = require('fs')
const path = require('path')
const os = require('os')

// ─── Platform helpers ────────────────────────────────────────────────────────
const isWindows = process.platform === 'win32'
const WHICH = isWindows ? 'where' : 'which'
const PYTHON = isWindows ? 'python' : 'python3'
const NULL_DEV = isWindows ? 'NUL' : '/dev/null'
const PIPE_FAIL = isWindows ? '2>NUL' : '2>/dev/null'

const command = process.argv[2] || 'help'

// ═══════════════════════════════════════════════════════════════════════════════
// Built-in Graph Builder (zero external deps, synchronous, regex-based)
// ═══════════════════════════════════════════════════════════════════════════════

function scanFiles(dir, pattern) {
  const files = []
  try {
    for (const entry of fs.readdirSync(dir)) {
      if (entry === 'node_modules' || entry === '.git' || entry === 'dist' ||
          entry === '.next' || entry === '__pycache__' || entry === 'graphify-out')
        continue
      const full = path.join(dir, entry)
      try {
        if (fs.statSync(full).isDirectory()) {
          files.push(...scanFiles(full, pattern))
        } else if (pattern.test(entry)) {
          files.push(full)
        }
      } catch (_) {}
    }
  } catch (_) {}
  return files
}

function extractImports(content) {
  const imports = []
  // TS/JS: import X from './path' / require('./path') / import('./path')
  const tsRe = /(?:import\s+(?:[\s\S]*?\s+from\s+)?['"]|require\s*\(\s*['"]|import\s*\(\s*['"])((?:\.\/|\.\.\/|@\/)[^'"]+)/g
  let m
  while ((m = tsRe.exec(content)) !== null) imports.push(m[1])
  // Python: from .module import X
  const pyRe = /^from\s+(\.\S+)\s+import/gm
  while ((m = pyRe.exec(content)) !== null) imports.push(m[1])
  return [...new Set(imports)]
}

function resolveImport(importPath, fromFile, root) {
  const fromDir = path.dirname(fromFile)
  let resolved = path.join(fromDir, importPath)
  const exts = ['.ts', '.tsx', '.js', '.jsx', '.py', '/index.ts', '/index.js']
  for (const ext of exts) {
    if (fs.existsSync(resolved + ext)) return resolved + ext
  }
  if (importPath.startsWith('@/')) {
    resolved = path.join(root, importPath.slice(2))
    for (const ext of exts) {
      if (fs.existsSync(resolved + ext)) return resolved + ext
    }
  }
  return null
}

function buildCodegraph(root) {
  const files = scanFiles(root, /\.(ts|tsx|js|jsx|py)$/)
  const importMap = {}

  for (const file of files) {
    try {
      const content = fs.readFileSync(file, 'utf-8')
      const raw = extractImports(content)
      const resolved = []
      for (const imp of raw) {
        const r = resolveImport(imp, file, root)
        if (r) resolved.push(path.relative(root, r))
      }
      if (resolved.length > 0) importMap[path.relative(root, file)] = [...new Set(resolved)]
    } catch (_) {}
  }

  const importerCount = {}
  for (const deps of Object.values(importMap)) {
    for (const dep of deps) {
      importerCount[dep] = (importerCount[dep] || 0) + 1
    }
  }

  const hubFiles = Object.entries(importerCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .map(([file, count]) => ({
      file,
      importers: count,
      risk: count >= 50 ? 'critical' : count >= 20 ? 'high' : count >= 10 ? 'medium' : 'low'
    }))

  const fanOutCounts = {}
  const fanOutFiles = Object.entries(importMap)
    .sort((a, b) => b[1].length - a[1].length)
    .slice(0, 12)
    .map(([file, deps]) => { fanOutCounts[file] = deps.length; return file })

  const apiDeps = {}
  for (const [file, deps] of Object.entries(importMap)) {
    if ((file.includes('api/') || file.includes('routes/')) &&
        (file.includes('route') || file.includes('handler'))) {
      apiDeps[file] = deps.filter(d => !d.includes('api/') && !d.includes('routes/'))
    }
  }

  return { hubFiles, fanOutFiles, apiDeps, fanOutCounts }
}

function buildGraphify(root) {
  const files = scanFiles(root, /\.(ts|tsx|js|jsx|md|css|py)$/)
  const nodes = []
  const communities = new Map()

  for (const file of files) {
    const rel = path.relative(root, file)
    const dir = path.dirname(rel).split('/')[0] || 'root'
    const ext = path.extname(file).slice(1)
    const typeMap = { ts:'typescript', tsx:'typescript', js:'javascript', jsx:'javascript', py:'python', md:'documentation', css:'stylesheet' }

    nodes.push({ name: rel, type: typeMap[ext] || ext, deps: [], community: 0 })
    if (!communities.has(dir)) communities.set(dir, [])
    communities.get(dir).push(rel)
  }

  let ci = 0
  const communityList = []
  for (const [name, nodeNames] of communities) {
    const cohesion = Math.min(0.99, +(0.01 + nodeNames.length / nodes.length).toFixed(2))
    communityList.push({ name, cohesion, nodes: nodeNames })
    for (const n of nodes) { if (nodeNames.includes(n.name)) n.community = ci }
    ci++
  }

  const edges = []
  for (let i = 0; i < nodes.length; i++)
    for (let j = i + 1; j < nodes.length; j++)
      if (nodes[i].community === nodes[j].community) edges.push([i, j])

  return { nodes, edges, communities: communityList }
}

function generateCodegraphMd(report) {
  const lines = [
    '# Code Dependency Graph — Auto-generated by ToonGine',
    '> Rebuild: `npx toongine graph`',
    '',
    '## Hub Files — Most Imported (highest blast radius)',
    '',
    '| # | File | Importers | Risk |',
    '|---|------|-----------|------|',
  ]
  report.hubFiles.forEach((h, i) => lines.push(`| ${i + 1} | \`${h.file}\` | **${h.importers}** | ${h.risk} |`))

  lines.push('', '## High Fan-Out Files (coupling risk)', '', '| # | File | Imports |', '|---|------|---------|')
  report.fanOutFiles.forEach((f, i) => lines.push(`| ${i + 1} | \`${f}\` | ${report.fanOutCounts[f] || '?'} |`))

  if (Object.keys(report.apiDeps).length > 0) {
    lines.push('', '## API Route Dependency Map', '')
    for (const [route, deps] of Object.entries(report.apiDeps)) {
      lines.push(`### \`${route}\` (${deps.length} deps)`)
      deps.forEach(d => lines.push(`  → \`${d}\``))
      lines.push('')
    }
  }

  lines.push('---', '', `_Generated by ToonGine on ${new Date().toISOString().split('T')[0]}_`)
  return lines.join('\n')
}

function generateGraphifyMd(report) {
  const lines = [
    '# Graph Report — Auto-generated by ToonGine',
    `> ${report.nodes.length} nodes · ${report.edges.length} edges · ${report.communities.length} communities`,
    '> Rebuild: `npx toongine graph`',
    '',
    '## Community Hubs (Navigation)',
    '',
  ]
  report.communities.forEach((c, i) => {
    lines.push(`- **Community ${i}**: \`${c.name}\` (${c.nodes.length} nodes, cohesion: ${c.cohesion})`)
  })

  lines.push('', '---', '')
  report.communities.forEach((c, i) => {
    lines.push(`### Community ${i} — "${c.name}"`)
    lines.push(`Cohesion: ${c.cohesion} · Nodes: ${c.nodes.length}`)
    const preview = c.nodes.slice(0, 15).join(', ')
    const suffix = c.nodes.length > 15 ? ` (+${c.nodes.length - 15} more)` : ''
    lines.push(`Files: ${preview}${suffix}`)
    lines.push('')
  })

  lines.push('---', '', `_Generated by ToonGine on ${new Date().toISOString().split('T')[0]}_`)
  return lines.join('\n')
}

function buildAllGraphs(rootDir) {
  // Output to .toon/graphify/ + .toon/codegraph/ — separate structured folders
  const graphifyDir = path.join(rootDir, '.toon', 'graphify')
  const codegraphDir = path.join(rootDir, '.toon', 'codegraph')
  fs.mkdirSync(graphifyDir, { recursive: true })
  fs.mkdirSync(codegraphDir, { recursive: true })

  const codegraph = buildCodegraph(rootDir)
  const codegraphMd = generateCodegraphMd(codegraph)
  const codegraphToon = mdToToon(codegraphMd)
  
  fs.writeFileSync(path.join(codegraphDir, 'CODEGRAPH_REPORT.toon'), codegraphToon)
  fs.writeFileSync(path.join(codegraphDir, 'CODEGRAPH_REPORT.md'), codegraphMd)

  const graphify = buildGraphify(rootDir)
  const graphifyMd = generateGraphifyMd(graphify)
  const graphifyToon = mdToToon(graphifyMd)
  
  fs.writeFileSync(path.join(graphifyDir, 'GRAPH_REPORT.toon'), graphifyToon)
  fs.writeFileSync(path.join(graphifyDir, 'GRAPH_REPORT.md'), graphifyMd)

  // Auto-detect and fix issues
  const issues = detectGraphIssues(codegraph, graphify, rootDir)
  if (issues.length > 0) {
    process.stdout.write('\n  🔍 Auto-detected ' + issues.length + ' issue(s):\n')
    issues.forEach(i => process.stdout.write('     ' + (i.severity === 'critical' ? '🔴' : '🟡') + ' ' + i.file + ': ' + i.message + '\n'))
    const fixed = autoFixIssues(issues, rootDir)
    if (fixed > 0) process.stdout.write('  ✅ Auto-fixed ' + fixed + ' issue(s)\n')
  }

  return { graphify: graphifyMd, codegraph: codegraphMd }
}

// Convert .md report to .toon format (abbreviated + indexed)
function mdToToon(md) {
  const lines = md.split('\n')
  const out = []
  out.push('SRC built-in')
  out.push('ORIG_SIZE ' + md.length)
  out.push('COMPILED ' + new Date().toISOString())
  out.push('---')
  
  for (const line of lines) {
    if (!line.trim() || line.match(/^[-|]+$/)) continue
    let cleaned = line
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/`(.+?)`/g, '$1')
      .replace(/\[(.+?)\]\(.+?\)/g, '$1')
      .replace(/#+\s*/g, '')
      .replace(/>\s*/g, '')
      .trim()
    if (cleaned) out.push(cleaned)
  }
  return out.join('\n')
}

// Detect issues from graph analysis
function detectGraphIssues(codegraph, graphify, rootDir) {
  const issues = []
  
  // Check for high blast radius files
  for (const hub of codegraph.hubFiles || []) {
    if (hub.risk === 'critical' && hub.importers > 40) {
      issues.push({
        file: hub.file,
        severity: 'critical',
        message: 'High blast radius — ' + hub.importers + ' importers. Consider splitting.',
        type: 'blast-radius'
      })
    }
  }
  
  // Check for missing CLAUDE.md
  if (!fs.existsSync(path.join(rootDir, 'CLAUDE.md'))) {
    issues.push({
      file: 'CLAUDE.md',
      severity: 'critical',
      message: 'Missing project CLAUDE.md — agents have no architecture context',
      type: 'missing-claude'
    })
  }
  
  // Check for high-coupling API routes
  for (const [file, deps] of Object.entries(codegraph.apiDeps || {})) {
    if (deps.length > 20) {
      issues.push({
        file: file,
        severity: 'warning',
        message: 'High coupling — ' + deps.length + ' dependencies on this API route',
        type: 'high-coupling'
      })
    }
  }
  
  return issues
}

// Auto-fix resolvable issues
function autoFixIssues(issues, rootDir) {
  let fixed = 0
  
  for (const issue of issues) {
    if (issue.type === 'missing-claude') {
      const content = '# CLAUDE.md\n> Auto-generated by ToonGine graph — add project architecture details here\n\n## App Architecture\n\n## Development Commands\n\n## Key Rules\n- Strict TypeScript — zero build errors\n- No manual deploys — CI/CD pipeline only\n'
      fs.writeFileSync(path.join(rootDir, 'CLAUDE.md'), content)
      fixed++
    }
    if (issue.type === 'blast-radius') {
      const filePath = path.join(rootDir, issue.file)
      if (fs.existsSync(filePath)) {
        let content = fs.readFileSync(filePath, 'utf-8')
        if (!content.includes('TOONGINE-HIGH-BLAST-RADIUS')) {
          content = '// ⚠️ TOONGINE-HIGH-BLAST-RADIUS: ' + issue.message + '\n' + content
          fs.writeFileSync(filePath, content)
          fixed++
        }
      }
    }
  }
  
  return fixed
}

// ═══════════════════════════════════════════════════════════════════════════════
// CLI Commands
// ═══════════════════════════════════════════════════════════════════════════════

function help() {
  console.log(`
ToonGine CLI v1.6.0

  toongine init          One command to activate everything (creates .toon/ structure)
  toongine integrate     Wire engine into an existing project (safe, non-destructive)
  toongine doctor        Health check (all ✅ except external services)
  toongine graph         Rebuild knowledge graphs → .toon/graphify/ + .toon/codegraph/
  toongine agents        List all agents from .toon/agents/
  toongine dashboard     Open live dashboard (port 3000)
  toongine dashboard --hide / --show / --status
  toongine absorb        Migrate originals → .toon/ (safe, with rollback)
  toongine absorb --dry-run   Preview what would move
  toongine rollback      List available rollback snapshots
  toongine rollback <ts> Restore from specific snapshot
  toongine sync --once   One-time sync: originals → .toon/
  toongine sync --watch  Auto-sync every 30s
  toongine hermes        Hermes bridge: connect / disconnect / status
  toongine compile       Build v4 knowledge graph + context engine
  toongine compile --force   Force rebuild graph (bypass cache)
  toongine compile --rebuild Rebuild all 3 tool graphs, then compile v4
  toongine rebuild       Rebuild tool graphs after code changes (no reinstall)
  toongine watch         Auto-compile on file changes (dev mode)
  toongine session-search <query>  TOON-compressed session search (Hermes state.db)
  toongine session-search --recent   Recent sessions (compressed)
  toongine clean         Remove stale duplicates + reindex engine.bin
  toongine stats         Show dual-doc stats + runtime savings
  toongine version       Show version

Project structure (after init):
  .toon/
  ├── dictionary.toon        ← project abbreviation dictionary
  ├── codegraph/             ← real Codegraph MCP (codegraph.db + CODEGRAPH_REPORT.toon)
  ├── graphify/              ← GRAPH_REPORT.{md,toon} (code structure graph)
  ├── code-review-graph/     ← Tree-sitter graph DB (pip install code-review-graph)
  ├── graph/                 ← unified.db — v4 graph intelligence
  ├── agents/                ← 24 agents across 11 departments
  ├── docs/                  ← compiled venture docs, plans, constitution
  ├── project/               ← compiled CLAUDE.md → CLAUDE.toon
  ├── hermes/                ← MCP server + bridge config
  └── v3/                    ← legacy (v4 graph/ replaces this)
`)
}

function init() {
  const cwd = process.cwd()
  console.log('\n  🚀 ToonGine v1.6.0 — Activating...\n')

  // ─── Detect features ─────────────────────────────────────────────────────
  const features = {
    hermes: fs.existsSync(path.join(os.homedir(), '.hermes', 'memories', 'USER.md')),
    claude: !!process.env.ANTHROPIC_API_KEY,
    nextjs: fs.existsSync(path.join(cwd, 'next.config.ts')) || fs.existsSync(path.join(cwd, 'next.config.js')),
    graphify: fs.existsSync(path.join(cwd, '.toon', 'graphify', 'GRAPH_REPORT.md')),
    codegraph: fs.existsSync(path.join(cwd, '.toon', 'codegraph', 'CODEGRAPH_REPORT.md')),
    agentMemory: fs.existsSync(path.join(cwd, '.toon', 'agents')),
    claudeMd: fs.existsSync(path.join(cwd, 'CLAUDE.md')),
    codeReviewGraph: checkCodeReviewGraph(),
  }

  function checkCodeReviewGraph() {
    try {
      const result = require('child_process').execSync(`${WHICH} code-review-graph`, { encoding: 'utf-8', timeout: 5000 })
      return !!result.trim()
    } catch { return false }
  }

  // ─── Create .toon/ project structure ────────────────────────────────────
  const toonDir = path.join(cwd, '.toon')
  fs.mkdirSync(toonDir, { recursive: true })

  const items = [
    ['.toon/dictionary.toon', '# TOON Dictionary\n> Project-specific abbreviations — rebuild: npx toongine compile\n'],
    ['.toon/project/.gitkeep', ''],
    ['.toon/codegraph/.gitkeep', ''],
    ['.toon/graphify/.gitkeep', ''],
    ['.toon/agents/.gitkeep', ''],
    ['.toon/docs/ventures/.gitkeep', ''],
    ['.toon/v3/.gitkeep', ''],
    ['.toon/hermes/.gitkeep', ''],
  ]

  console.log('  📁 Building .toon/ project structure...\n')
  for (const [file, content] of items) {
    const full = path.join(cwd, file)
    if (fs.existsSync(full)) {
      console.log(`  ✅ (exists) ${file}`)
    } else {
      mkdir(path.dirname(full))
      if (content) fs.writeFileSync(full, content)
      console.log(`  📦 ${file}`)
    }
  }

  // ─── Create Hermes bridge config ──────────────────────────────────────
  const hermesConfigPath = path.join(cwd, '.toon', 'hermes', 'config.json')
  if (!fs.existsSync(hermesConfigPath)) {
    const hermesCfg = {
      connected: false,
      hermesHome: path.join(os.homedir(), '.hermes'),
      sync: { memories: true, skills: true, sessions: true, cron: false },
      bridge: { enabled: false, direction: 'bidirectional', autoSync: false },
      lastSync: null,
      agentProfile: null
    }
    fs.writeFileSync(hermesConfigPath, JSON.stringify(hermesCfg, null, 2))
    console.log('  📦 .toon/hermes/config.json')
  }

  // ─── Ensure CLAUDE.md exists at root ────────────────────────────────────
  const claudePath = path.join(cwd, 'CLAUDE.md')
  let claudeContent = ''
  if (!fs.existsSync(claudePath)) {
    claudeContent = '# CLAUDE.md\n> Project architecture and rules\n> Auto-generated by ToonGine — add your project details here\n\n## App Architecture\n\n## Development Commands\n\n## Key Rules\n- Strict TypeScript — zero build errors\n- No manual deploys — CI/CD pipeline only\n'
    fs.writeFileSync(claudePath, claudeContent)
    console.log('  📦 CLAUDE.md (project root)')
  } else {
    claudeContent = fs.readFileSync(claudePath, 'utf-8')
    console.log('  ✅ CLAUDE.md (exists)')
  }
  // Compile CLAUDE.md → .toon/project/CLAUDE.toon (compressed project spec)
  const claudeToon = mdToToon(claudeContent)
  fs.writeFileSync(path.join(cwd, '.toon', 'project', 'CLAUDE.toon'), claudeToon)
  console.log('  📦 .toon/project/CLAUDE.toon (compiled)')

  // ─── Deploy agents to .toon/agents/ ─────────────────────────────────────
  console.log('\n  👥 Deploying agents...\n')

  const templateDir = path.join(__dirname, 'templates', 'agents')
  const agentDir = path.join(cwd, '.toon', 'agents')
  let agentsCreated = 0

  if (fs.existsSync(templateDir)) {
    // Templates shipped with package — deploy agents
    const depts = fs.readdirSync(templateDir).filter(d => {
      const full = path.join(templateDir, d)
      return fs.statSync(full).isDirectory() && d !== 'skills' && d !== 'brands' && d !== 'DEPARTMENTS.md'
    })

    for (const dept of depts) {
      const agents = fs.readdirSync(path.join(templateDir, dept)).filter(a =>
        fs.statSync(path.join(templateDir, dept, a)).isDirectory()
      )
      for (const agent of agents) {
        const src = path.join(templateDir, dept, agent)
        const dest = path.join(agentDir, dept, agent)
        if (!fs.existsSync(dest)) {
          copyDir(src, dest)
          agentsCreated++
        }
      }
    }

    // Copy DEPARTMENTS.md to agents root
    const depsSrc = path.join(templateDir, 'DEPARTMENTS.md')
    if (fs.existsSync(depsSrc)) {
      fs.copyFileSync(depsSrc, path.join(agentDir, 'DEPARTMENTS.md'))
    }
  } else {
    // Templates not shipped (git-cloned on Windows) — create stubs from registry
    deployAgentStubs(agentDir)
    agentsCreated = 24
  }
  console.log(`  ✅ ${agentsCreated} new agents deployed to .toon/agents/`)

  // ─── Real Codegraph (MCP graph engine) → .toon/codegraph/ ────────────
  console.log('\n  🧠 Codegraph — MCP graph engine...\n')

  // Step 1: Ensure codegraph CLI is installed (global, one-time)
  let hasCodegraph = false
  try {
    hasCodegraph = !!require('child_process').execSync(`${WHICH} codegraph`, { encoding: 'utf-8', timeout: 5000 }).trim()
  } catch (e) {}
  
  if (!hasCodegraph) {
    try {
      console.log('  📦 Installing codegraph CLI...')
      require('child_process').execSync('npm i -g @colbymchenry/codegraph', { timeout: 120000 })
      hasCodegraph = true
    } catch (e) {
      console.log(`  ⚠️  codegraph install failed: ${e.message.trim().split('\\n')[0]}`)
    }
  }

  // Step 2: Wire codegraph MCP to Hermes (one-time)
  if (hasCodegraph) {
    try {
      require('child_process').execSync('codegraph install --yes', { timeout: 30000 })
      console.log('  ✅ Codegraph MCP wired to Hermes')
    } catch (e) {
      console.log(`  ⚠️  codegraph install: ${e.message.trim().split('\\n')[0]}`)
    }

    // Step 3: Build codegraph for this project
    try {
      console.log('  🔬 Building codegraph...')
      require('child_process').execSync('codegraph init', { timeout: 120000, cwd: cwd })
      console.log('  ✅ Codegraph built → .codegraph/codegraph.db')
    } catch (e) {
      console.log(`  ⚠️  codegraph init: ${e.message.trim().split('\\n')[0]}`)
    }

    // Step 4: Synthesize codegraph DB → .toon/codegraph/CODEGRAPH_REPORT.toon
    try {
      const synthScript = path.join(__dirname, 'scripts', 'synthesize-codegraph.py')
      if (fs.existsSync(synthScript)) {
        require('child_process').execSync(`${PYTHON} "${synthScript}" "${cwd}"`, { timeout: 30000 })
      }
    } catch (e) {
      console.log(`  ⚠️  synthesize: ${e.message.trim().split('\\n')[0]}`)
    }

    // Step 5: Move .codegraph/ into .toon/codegraph/
    const cgDir = path.join(cwd, '.codegraph')
    const toonCgDir = path.join(cwd, '.toon', 'codegraph')
    if (fs.existsSync(cgDir)) {
      try {
        const cgFiles = fs.readdirSync(cgDir)
        for (const f of cgFiles) {
          const src = path.join(cgDir, f)
          const dest = path.join(toonCgDir, f)
          if (fs.existsSync(dest)) {
            if (fs.statSync(src).isDirectory()) continue // skip dirs
            fs.unlinkSync(dest)
          }
          fs.renameSync(src, dest)
        }
        fs.rmdirSync(cgDir)
        console.log('  ✅ .codegraph/ → .toon/codegraph/')
      } catch (e) {
        console.log(`  ⚠️  move .codegraph/: ${e.message}`)
      }
    }

    // Step 6: Clean up any stale Claude Code local-install leftovers
    const staleFiles = ['.mcp.json', path.join('.claude', 'settings.json'), path.join('.claude', 'CLAUDE.md')]
    for (const sf of staleFiles) {
      const sfPath = path.join(cwd, sf)
      if (fs.existsSync(sfPath)) {
        try {
          // Move into .toon/claude/ for safekeeping
          const toonClaudeDir = path.join(cwd, '.toon', 'claude')
          fs.mkdirSync(toonClaudeDir, { recursive: true })
          const destName = sf.replace(/[/\\]/g, '_').replace(/^\./, '')
          fs.renameSync(sfPath, path.join(toonClaudeDir, destName))
          console.log(`  🧹 Cleaned: ${sf} → .toon/claude/${destName}`)
        } catch (e) {
          console.log(`  ⚠️  cleanup ${sf}: ${e.message}`)
        }
      }
    }
    // Remove empty .claude/ dir if we moved everything
    const claudeDir = path.join(cwd, '.claude')
    if (fs.existsSync(claudeDir)) {
      try {
        const remaining = fs.readdirSync(claudeDir)
        if (remaining.length === 0) fs.rmdirSync(claudeDir)
      } catch (e) {}
    }
  }

  // ─── Real Graphify (70k★ semantic graph) → .toon/graphify/ ──────────
  console.log('\n  📊 Graphify — semantic knowledge graph...\n')

  let hasGraphify = false
  try {
    hasGraphify = !!require('child_process').execSync(`${WHICH} graphify`, { encoding: 'utf-8', timeout: 5000 }).trim()
  } catch (e) {}

  if (!hasGraphify) {
    try {
      console.log('  📦 Installing graphify...')
      require('child_process').execSync(`${PYTHON} -m pip install graphifyy`, { timeout: 120000 })
      try {
        require('child_process').execSync(`graphify install --platform hermes`, { timeout: 30000 })
      } catch {
        require('child_process').execSync(`${PYTHON} -m graphify install --platform hermes`, { timeout: 30000 })
      }
      hasGraphify = true
    } catch (e) {
      console.log(`  ⚠️  graphify install: ${e.message.trim().split('\\\\n')[0]}`)
    }
  }

  if (hasGraphify) {
    // Detect API key for headless extraction
    const apiKey = process.env.DEEPSEEK_API_KEY || process.env.ANTHROPIC_API_KEY || process.env.OPENAI_API_KEY || ''
    if (apiKey) {
      try {
        console.log('  🔬 Running graphify extract (semantic LLM)...')
        try {
          require('child_process').execSync('graphify extract . --backend auto --out .toon/graphify', { timeout: 300000, cwd: cwd })
        } catch {
          require('child_process').execSync(`${PYTHON} -m graphify extract . --backend auto --out .toon/graphify`, { timeout: 300000, cwd: cwd })
        }
        console.log('  ✅ Graphify → .toon/graphify/graphify-out/')
        // Move graphify-out/* up one level into .toon/graphify/
        const gfOut = path.join(cwd, '.toon', 'graphify', 'graphify-out')
        if (fs.existsSync(gfOut)) {
          const gfFiles = fs.readdirSync(gfOut)
          for (const f of gfFiles) {
            fs.renameSync(path.join(gfOut, f), path.join(cwd, '.toon', 'graphify', f))
          }
          fs.rmdirSync(gfOut)
          console.log('  ✅ graphify-out/ → .toon/graphify/')
          // Synthesize graph.json → GRAPH_REPORT.toon
          try {
            const synthScript = path.join(__dirname, 'scripts', 'synthesize-graphify.py')
            if (fs.existsSync(synthScript)) {
              require('child_process').execSync(`${PYTHON} "${synthScript}" "${cwd}"`, { timeout: 30000 })
            }
          } catch (e2) {
            console.log(`  ⚠️  synthesize-graphify: ${e2.message.trim().split('\\n')[0]}`)
          }
        }
      } catch (e) {
        console.log(`  ⚠️  graphify extract: ${e.message.trim().split('\\n')[0]}`)
        console.log('  ℹ️  Falling back to built-in regex graphify')
        hasGraphify = false
      }
    } else {
      console.log('  ⚠️  No API key — set DEEPSEEK_API_KEY or ANTHROPIC_API_KEY for real graphify')
      hasGraphify = false
    }
  }

  // Fallback: built-in regex graphify (no API needed)
  if (!hasGraphify) {
    try {
      const graphify = buildGraphify(cwd)
      const graphifyMd = generateGraphifyMd(graphify)
      const graphifyToon = mdToToon(graphifyMd)
      fs.writeFileSync(path.join(cwd, '.toon', 'graphify', 'GRAPH_REPORT.toon'), graphifyToon)
      fs.writeFileSync(path.join(cwd, '.toon', 'graphify', 'GRAPH_REPORT.md'), graphifyMd)
      console.log(`  ✅ Graphify (regex): ${(graphifyMd.length / 1024).toFixed(1)} KB → .toon/graphify/`)
    } catch (e) {
      console.log(`  ⚠️  Graphify regex: ${e.message}`)
    }
  }

  // ─── Code-Review-Graph (Tree-sitter) → .toon/code-review-graph/ ────
  console.log('\n  🔬 Code-Review-Graph — Tree-sitter engine...\n')
  
  if (!features.codeReviewGraph) {
    try {
      console.log('  📦 Installing code-review-graph...')
      require('child_process').execSync(`${PYTHON} -m pip install code-review-graph`, { timeout: 60000 })
      features.codeReviewGraph = true
    } catch (e) {
      console.log(`  ⚠️  code-review-graph install: ${e.message.trim().split('\\\\n')[0]}`)
    }
  }

  if (features.codeReviewGraph) {
    // Step A: Wire to platforms
    try {
      try {
        require('child_process').execSync('code-review-graph install --yes', { timeout: 30000, cwd: cwd })
      } catch {
        require('child_process').execSync(`${PYTHON} -m code_review_graph install --yes`, { timeout: 30000, cwd: cwd })
      }
      console.log('  ✅ code-review-graph wired')
    } catch (e) {
      console.log(`  ⚠️  code-review-graph install: ${e.message.trim().split('\\n')[0]}`)
    }

    // Step B: Build graph into .toon/ (needs .git for repo detection)
    try {
      // code-review-graph requires a git repo — init one if missing
      if (!fs.existsSync(path.join(cwd, '.git'))) {
        require('child_process').execSync('git init', { timeout: 10000, cwd })
        console.log('  📦 git init (required by code-review-graph)')
      }
      try {
        require('child_process').execSync('code-review-graph build --data-dir .toon/code-review-graph/', { timeout: 60000, cwd: cwd })
      } catch {
        require('child_process').execSync(`${PYTHON} -m code_review_graph build --data-dir .toon/code-review-graph/`, { timeout: 60000, cwd: cwd })
      }
      console.log('  ✅ Code-Review-Graph → .toon/code-review-graph/')
      // Synthesize graph.db → CODEGRAPH_REPORT.toon
      try {
        const synthScript = path.join(__dirname, 'scripts', 'synthesize-code-review-graph.py')
        if (fs.existsSync(synthScript)) {
          require('child_process').execSync(`${PYTHON} "${synthScript}" "${cwd}"`, { timeout: 30000 })
        }
      } catch (e2) {
        console.log(`  ⚠️  synthesize-crg: ${e2.message.trim().split('\\n')[0]}`)
      }
    } catch (e) {
      console.log(`  ⚠️  code-review-graph build: ${e.message.trim().split('\\n')[0]}`)
    }

    // Step C: Clean up platform files code-review-graph install leaked
    const crgLeakDirs = ['.claude', '.gemini', '.qoder', '.kiro', '.github']
    const crgLeakFiles = ['.mcp.json', '.opencode.json', 'AGENTS.md', 'GEMINI.md', 'QODER.md', '.cursorrules', '.windsurfrules']
    
    const toonCrgDir = path.join(cwd, '.toon', 'code-review-graph')
    fs.mkdirSync(toonCrgDir, { recursive: true })
    
    // Move leaked directories
    for (const d of crgLeakDirs) {
      const dp = path.join(cwd, d)
      if (fs.existsSync(dp)) {
        try {
          const dest = path.join(toonCrgDir, d.replace(/^\./, ''))
          fs.renameSync(dp, dest)
        } catch (e) {}
      }
    }
    // Move leaked root files
    for (const f of crgLeakFiles) {
      const fp = path.join(cwd, f)
      if (fs.existsSync(fp)) {
        try {
          const destName = f.replace(/^\./, '')
          fs.renameSync(fp, path.join(toonCrgDir, destName))
        } catch (e) {}
      }
    }
    // Clean .gitignore: remove code-review-graph entry
    const giPath = path.join(cwd, '.gitignore')
    if (fs.existsSync(giPath)) {
      try {
        let giContent = fs.readFileSync(giPath, 'utf-8')
        if (giContent.includes('code-review-graph')) {
          giContent = giContent.split('\n').filter(l => !l.includes('code-review-graph')).join('\n')
          fs.writeFileSync(giPath, giContent)
        }
        // If .gitignore is now empty or only whitespace, remove it
        if (giContent.trim() === '') fs.unlinkSync(giPath)
      } catch (e) {}
    }
  }

  // ─── Final Cleanup: move any remaining leaked dot-dirs into .toon/ ────
  const allLeakDirs = ['.claude', '.gemini', '.qoder', '.kiro', '.codegraph']
  const allLeakFiles = ['.mcp.json', '.opencode.json', 'AGENTS.md', 'GEMINI.md', 'QODER.md', '.cursorrules', '.windsurfrules']
  
  for (const d of allLeakDirs) {
    const dp = path.join(cwd, d)
    if (fs.existsSync(dp)) {
      try {
        const dest = path.join(cwd, '.toon', 'code-review-graph', d.replace(/^\./, ''))
        // Remove existing if present
        if (fs.existsSync(dest)) {
          try { fs.rmSync(dest, { recursive: true }) } catch (e) {}
        }
        fs.renameSync(dp, dest)
        console.log(`  🧹 Cleaned: ${d}/ → .toon/code-review-graph/`)
      } catch (e) {}
    }
  }
  for (const f of allLeakFiles) {
    const fp = path.join(cwd, f)
    if (fs.existsSync(fp)) {
      try {
        const destName = f.replace(/^\./, '')
        fs.renameSync(fp, path.join(cwd, '.toon', 'code-review-graph', destName))
        console.log(`  🧹 Cleaned: ${f} → .toon/code-review-graph/`)
      } catch (e) {}
    }
  }

  // ─── Write config ────────────────────────────────────────────────────────
  const config = {
    version: '1.6.0',
    projectRoot: cwd,
    graphifyReport: path.join(cwd, '.toon', 'graphify', 'GRAPH_REPORT.md'),
    codegraphReport: path.join(cwd, '.toon', 'codegraph', 'CODEGRAPH_REPORT.md'),
    agentMemoryDir: path.join(cwd, '.toon', 'memory'),
    hermesMemoryDir: path.join(os.homedir(), '.hermes', 'memories'),
    projectClaudePath: path.join(cwd, 'CLAUDE.md'),
    ventureDocsDir: path.join(cwd, 'docs', 'ventures'),
    cieEnabled: true,
    contextCap: 2500,
    adaptiveInjection: true,
    toonEnabled: true,
    toonBidirectional: true,
    hermesSync: features.hermes,
    claudeAvailable: features.claude,
    agents: agentsCreated || 13,
    builtIn: ['graphify', 'codegraph', 'code-review-graph'],
    codeReviewGraph: features.codeReviewGraph,
  }
  fs.writeFileSync(path.join(cwd, 'toongine.config.json'), JSON.stringify(config, null, 2))

  // ─── V4 Graph Activation ──────────────────────────────────────────────
  console.log('\n  🧬 Building v4 graph intelligence...\n')
  try {
    const { activate } = require('./dist/toon/v4/auto-activate')
    const report = activate(cwd)
    console.log(`  ✅ Graph: ${report.graphNodes} nodes / ${report.graphEdges} edges`)
    console.log(`  ✅ MCP server deployed → .toon/hermes/mcp-server.py`)
    // Auto-wire toongine MCP into ~/.hermes/config.yaml
    try {
      const wireScript = path.join(__dirname, 'scripts', 'wire-hermes-mcp.py')
      if (fs.existsSync(wireScript)) {
        require('child_process').execSync(`${PYTHON} "${wireScript}" "${cwd}"`, { timeout: 10000 })
      }
    } catch (e) {
      console.log(`  ⚠️  Hermes MCP auto-wire: ${e.message.trim().split('\n')[0]}`)
    }
    if (report.errors.length > 0) {
      report.errors.forEach(e => console.log(`  ⚠️  ${e}`))
    }
    console.log(`  ⏱️  ${report.durationMs}ms`)
  } catch (e) {
    console.log(`  ⚠️  v4 graph: ${e.message}`)
  }

  // ─── Summary ─────────────────────────────────────────────────────────────
  console.log('\n  ──────────────────────────────────────────────')
  console.log('  ✅ ToonGine activated!')
  console.log('  ──────────────────────────────────────────────\n')
  console.log(`  📁 .toon/ structure created`)
  console.log(`  🧠 Codegraph (MCP) → .toon/codegraph/ (${hasCodegraph ? '✅ real SQLite graph' : '⚠️  not installed'})`)
  console.log(`  📊 Graphify → .toon/graphify/ (${hasGraphify ? '✅ real semantic graph' : '⚠️  regex fallback'})`)
  console.log(`  🔬 Code-Review-Graph → .toon/code-review-graph/`)
  console.log(`  👥 Agents → .toon/agents/`)
  console.log(`  🔗 Hermes: ${features.hermes ? '✅ Connected' : '⚠️  Install Hermes Agent'}`)
  console.log(`  🤖 Claude: ${features.claude ? '✅ ANTHROPIC_API_KEY set' : '⚠️  Set ANTHROPIC_API_KEY in .env'}`)
  console.log(`\n  Next: npx toongine doctor   (health check)`)
  console.log(`        npx toongine compile   (compress everything)`)
  console.log(`        npx toongine stats     (runtime savings)`)
}

function doctor() {
  const flag = process.argv[3]
  console.log('\n  🏥 ToonGine — Health Check\n')

  const cwd = process.cwd()
  const configPath = path.join(cwd, 'toongine.config.json')

  if (!fs.existsSync(configPath)) {
    console.log('  ❌ Not initialized. Run: npx toongine init')
    return
  }

  const cfg = JSON.parse(fs.readFileSync(configPath, 'utf-8'))
  const hasHermes = fs.existsSync(path.join(os.homedir(), '.hermes', 'memories', 'USER.md'))
  const hasClaude = !!process.env.ANTHROPIC_API_KEY
  let hasCodeReviewGraph = false
  try {
    hasCodeReviewGraph = !!require('child_process').execSync(`${WHICH} code-review-graph`, { encoding: 'utf-8', timeout: 5000 }).trim()
  } catch {}

  // Count agents from .toon/agents/
  const agentDir = cfg.agentMemoryDir || path.join(cwd, '.toon', 'agents')
  const agentCount = countAgentsDeep(agentDir)
  
  const checks = [
    ['Graphify', fs.existsSync(cfg.graphifyReport || path.join(cwd, '.toon', 'graphify', 'GRAPH_REPORT.md')), '✅ Real semantic graph'],
    ['Codegraph (MCP)', fs.existsSync(cfg.codegraphReport || path.join(cwd, '.toon', 'codegraph', 'CODEGRAPH_REPORT.md')), '✅ MCP engine'],
    ['Agent Memory', fs.existsSync(agentDir), `${agentCount} agents`],
    ['CLAUDE.md', fs.existsSync(cfg.projectClaudePath || path.join(cwd, 'CLAUDE.md')), '✅'],
    ['Venture Docs', fs.existsSync(cfg.ventureDocsDir || path.join(cwd, 'docs', 'ventures')), '✅'],
    ['CIE Engine', cfg.cieEnabled !== false, `✅ Adaptive (cap: ${cfg.contextCap || 2500})`],
    ['TOON Compression', cfg.toonEnabled !== false || cfg.toon?.enabled, `✅ ${cfg.toonBidirectional || cfg.toon?.bidirectional ? 'Bidirectional' : 'Input'}`],
    ['Knowledge Graphs', true, '✅ Built-in (no external deps)'],
    ['Code-Review-Graph (built-in)', true, hasCodeReviewGraph ? '✅ Tree-sitter MCP engine' : '✅ Regex engine (pip install for Tree-sitter)'],
    ['Hermes', hasHermes, hasHermes ? '🔗 Connected' : '⚠️  External service'],
    ['Claude API', hasClaude, hasClaude ? '🤖 Connected' : '⚠️  External service'],
  ]

  let pass = 0
  for (const [name, ok, detail] of checks) {
    const icon = name === 'Hermes' || name === 'Claude API'
      ? (ok ? '🔗' : '⚠️ ') : (ok ? '✅' : '❌')
    if (ok || name === 'Hermes' || name === 'Claude API') pass++
    console.log(`  ${icon} ${name}: ${detail}`)
  }

  // ─── --stale: check tool freshness vs source code ────────────────────────
  if (flag === '--stale') {
    console.log('\n  ── Tool Staleness ──\n')
    const { statSync } = require('fs')
    
    // Find most recent source file change
    let latestSourceChange = 0
    const sourceDirs = [cwd]
    const skipDirs = /node_modules|\.next|\.git|dist|\.toon|graphify-out|\.code-review-graph|\.codegraph/
    
    function scanDir(dir, depth = 0) {
      if (depth > 4) return
      try {
        for (const entry of fs.readdirSync(dir)) {
          if (skipDirs.test(entry)) continue
          const full = path.join(dir, entry)
          try {
            const st = statSync(full)
            if (st.isDirectory()) {
              scanDir(full, depth + 1)
            } else if (/\.(ts|tsx|js|jsx|py|md|json|yml|yaml)$/.test(entry)) {
              if (st.mtimeMs > latestSourceChange) latestSourceChange = st.mtimeMs
            }
          } catch {}
        }
      } catch {}
    }
    scanDir(cwd)
    
    const now = Date.now()
    const sourceAge = now - latestSourceChange
    
    // Check each tool's output freshness
    const tools = [
      { name: 'Codegraph',       path: '.toon/codegraph/codegraph.db',      label: 'codegraph.db' },
      { name: 'Graphify',        path: '.toon/graphify/graph.json',          label: 'graph.json' },
      { name: 'Code-Review-Graph', path: '.toon/code-review-graph/graph.db', label: 'graph.db' },
      { name: 'Unified Graph',   path: '.toon/graph/unified.db',             label: 'unified.db' },
      { name: 'TOON Dictionary', path: '.toon/dictionary.toon',              label: 'dictionary.toon' },
    ]
    
    let staleCount = 0
    for (const tool of tools) {
      const toolPath = path.join(cwd, tool.path)
      if (!fs.existsSync(toolPath)) {
        console.log(`  ❌ ${tool.name}: missing (${tool.label}) — run npx toongine rebuild`)
        staleCount++
        continue
      }
      const toolStat = statSync(toolPath)
      const toolAge = now - toolStat.mtimeMs
      const ageStr = formatAge(toolAge)
      
      // Tool is stale if source changed more recently than tool output
      if (latestSourceChange > toolStat.mtimeMs) {
        const delta = latestSourceChange - toolStat.mtimeMs
        console.log(`  ⚠️  ${tool.name}: STALE — source changed ${formatAge(delta)} after last build (${ageStr} old)`)
        staleCount++
      } else {
        console.log(`  ✅ ${tool.name}: fresh (${ageStr} old)`)
      }
    }
    
    // Show staleness timestamp
    const stalenessFile = path.join(cwd, '.toon', '.tool-staleness.json')
    if (fs.existsSync(stalenessFile)) {
      const staledata = JSON.parse(fs.readFileSync(stalenessFile, 'utf-8'))
      if (staledata.lastToolRebuild) {
        const rebuildAge = now - new Date(staledata.lastToolRebuild).getTime()
        console.log(`\n  🕐 Last full rebuild: ${formatAge(rebuildAge)} ago${staledata.triggeredBy ? ` (${staledata.triggeredBy})` : ''}`)
      }
    }
    
    if (staleCount > 0) {
      console.log(`\n  🔴 ${staleCount} tool(s) stale — run: npx toongine rebuild`)
      console.log('     Or start watcher: npx toongine watch  (auto-rebuilds in 5m)')
    } else {
      console.log('\n  🟢 All tools up to date with source code')
    }
  }

  console.log(`\n  ${pass}/${checks.length} operational`)
  console.log('  Built-in engines: graphify ✅ codegraph ✅ CIE ✅ TOON ✅ Code-Review-Graph ✅')
  console.log('  External services: Hermes (optional) · Claude (set API key)')
}

function formatAge(ms) {
  if (ms < 60000) return `${Math.round(ms/1000)}s`
  if (ms < 3600000) return `${Math.round(ms/60000)}m`
  if (ms < 86400000) return `${Math.round(ms/3600000)}h`
  return `${Math.round(ms/86400000)}d`
}

// Count actual agent directories (3 levels deep: agents/CEO/marcus)
function countAgentsDeep(dir) {
  if (!fs.existsSync(dir)) return '0'
  // Now dir = .toon/agents directly (departments at level 1)
  let c = 0
  for (const dept of fs.readdirSync(dir)) {
    const deptPath = path.join(dir, dept)
    if (fs.statSync(deptPath).isDirectory()) {
      for (const agent of fs.readdirSync(deptPath)) {
        if (fs.statSync(path.join(deptPath, agent)).isDirectory()) c++
      }
    }
  }
  return String(c)
}

function graph() {
  console.log('\n  🧠 Building knowledge graphs...\n')
  const cwd = process.cwd()
  try {
    const result = buildAllGraphs(cwd)
    console.log(`  ✅ Graphify: ${(result.graphify.length / 1024).toFixed(1)} KB → .toon/graphify/`)
    console.log(`  ✅ Codegraph: ${(result.codegraph.length / 1024).toFixed(1)} KB → .toon/codegraph/`)
  } catch (e) {
    console.log(`  ❌ Failed: ${e.message}`)
    console.log('  Run: npx toongine init first')
  }
}

function agents() {
  const flag = process.argv[3]
  const cwd = process.cwd()
  
  // --sync: sync all manifests → generate Hermes skills + TOON files
  if (flag === '--sync') {
    console.log('\n  🔄 Syncing agents from manifests...\n')
    try {
      const { loadRegistry } = require('./dist/agents/registry')
      const reg = loadRegistry(cwd)
      console.log(`  📋 ${reg.total} manifests loaded`)
      console.log(`  ✅ ${reg.valid} valid`)
      if (reg.errors > 0) {
        console.log(`  ❌ ${reg.errors} errors:`)
        reg.validations.filter(v => !v.valid).forEach(v => {
          console.log(`     ${v.agent_id}: ${v.errors.join(', ')}`)
        })
      }
      console.log(`\n  👥 Agent Registry:`)
      reg.agents.forEach(a => {
        console.log(`     ${a.agent.id.padEnd(28)} L${a.agent.level} ${a.agent.department}`)
      })
      console.log(`\n  ✅ Sync complete.\n`)
    } catch(e) { console.log(`  ❌ ${e.message}\n`) }
    return
  }
  
  // --verify: verify all manifests
  if (flag === '--verify') {
    console.log('\n  🧪 Verifying all agents...\n')
    try {
      const { loadRegistry } = require('./dist/agents/registry')
      const reg = loadRegistry(cwd)
      const ok = reg.valid
      const total = reg.total
      const errors = reg.errors
      console.log(`  ${ok}/${total} operational`)
      if (errors > 0) {
        console.log(`  ❌ ${errors} agents have errors`)
        console.log('')
        reg.validations.filter(v => !v.valid).forEach(v => {
          console.log(`  ❌ ${v.agent_id}`)
          v.errors.forEach(e => console.log(`     - ${e}`))
        })
      } else {
        console.log('  ✅ All agents validated')
      }
      console.log('')
    } catch(e) { console.log(`  ❌ ${e.message}\n`) }
    return
  }

  console.log('\n  👥 YVON Agents\n')
  const memDir = path.join(cwd, '.toon', 'agents')
  if (!fs.existsSync(memDir)) { 
    // Fallback to legacy path
    const legacyDir = path.join(cwd, 'agent-memory')
    if (fs.existsSync(legacyDir)) {
      console.log('  ⚠️  Agents at legacy path: agent-memory/ — run: npx toongine init')
      listAgentsFrom(legacyDir)
      return
    }
    console.log('  No agents found. Run: npx toongine init')
    return 
  }
  listAgentsFrom(memDir)
}

function listAgentsFrom(memDir) {
  const deptNames = { CEO: 'Direction', COO: 'Operations', Command: 'Governance', Technical: 'Shipping', Marketing: 'Revenue', Finance: 'Finance', Legal: 'Legal', Psychology: 'Validation', Research: 'Research', Sense: 'Monitoring' }
  let total = 0
  for (const dept of fs.readdirSync(memDir)) {
    const dp = path.join(memDir, dept)
    if (!fs.statSync(dp).isDirectory() || dept === 'skills' || dept === 'brands' || dept.startsWith('.')) continue
    if (dept === 'DEPARTMENTS.md' || dept === 'DEPARTMENTS.toon') continue
    const agents = fs.readdirSync(dp).filter(a => fs.statSync(path.join(dp, a)).isDirectory())
    console.log(`  ${dept} — ${deptNames[dept] || ''}`)
    for (const agent of agents) {
      const ap = path.join(dp, agent)
      const files = fs.readdirSync(ap).filter(f => f.endsWith('.md')).length
      const hasSkills = fs.existsSync(path.join(ap, 'skills'))
      console.log(`    ${agent.padEnd(20)} ${files} docs${hasSkills ? ' + skills/' : ''}`)
      total++
    }
    console.log('')
  }
  console.log(`  Total: ${total} agents`)
}

function integrate() {
  const cwd = process.cwd()
  const pkgPath = path.join(cwd, 'package.json')
  
  if (!fs.existsSync(pkgPath)) {
    console.log('  ⚠️  No package.json found — not a Node.js project')
    console.log('  Run: npx toongine init  (for new projects)')
    process.exit(1)
  }
  
  // ── Step 1: Check if toongine is installed ───────────────────────────────
  const enginePath = path.join(cwd, 'node_modules', 'toongine')
  let engineInstalled = fs.existsSync(enginePath)
  
  if (!engineInstalled) {
    // also check old paths
    const oldPaths = [
      path.join(cwd, 'node_modules', 'toongine-engine'),
      path.join(cwd, 'node_modules', '@toongine', 'engine'),
    ]
    for (const p of oldPaths) {
      if (fs.existsSync(p)) { engineInstalled = true; break }
    }
  }
  
  if (!engineInstalled) {
    console.log('  📦 toongine not installed. Installing...')
    const { execSync } = require('child_process')
    try {
      execSync('npm install toongine', { cwd, stdio: 'inherit' })
      console.log('  ✅ Installed\n')
    } catch (e) {
      console.log('  ❌ Install failed:', e.message)
      process.exit(1)
    }
  }
  
  // ── Step 2: Map of local → engine imports ───────────────────────────────
  const replacements = {
    '@/lib/cie': 'toongine/cie',
    '@/lib/toon': 'toongine/toon',
    '@/lib/algorithms': 'toongine/algorithms',
    '@toongine/engine/cie': 'toongine/cie',
    '@toongine/engine/toon': 'toongine/toon',
    '@toongine/engine/algorithms': 'toongine/algorithms',
    'toongine-engine/cie': 'toongine/cie',
    'toongine-engine/toon': 'toongine/toon',
    'toongine-engine/algorithms': 'toongine/algorithms',
  }
  
  const stats = { scanned: 0, patched: 0, already: 0, errors: 0 }
  
  // ── Step 3: Scan all TS/TSX files ────────────────────────────────────────
  function scanDir(dir) {
    if (!fs.existsSync(dir)) return
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name === 'node_modules' || entry.name === '.git' || 
          entry.name === '.next' || entry.name === 'dist') continue
      const full = path.join(dir, entry.name)
      if (entry.isDirectory()) { scanDir(full) }
      else if (/\.(ts|tsx)$/.test(entry.name)) {
        stats.scanned++
        let content = fs.readFileSync(full, 'utf-8')
        let changed = false
        
        for (const [localPath, enginePath] of Object.entries(replacements)) {
          const importRe = new RegExp(
            `(from\\s+['"])${localPath.replace(/\//g, '\\/')}(['"])`, 'g'
          )
          const newContent = content.replace(importRe, `$1${enginePath}$2`)
          if (newContent !== content) {
            changed = true
            content = newContent
          }
        }
        
        if (changed) {
          // Verify the engine main entry exists on disk before patching
          const mainEntry = path.join(enginePath, 'dist', 'index.js')
          const safe = fs.existsSync(mainEntry)
          
          if (safe) {
            fs.writeFileSync(full, content, 'utf-8')
            stats.patched++
            console.log(`  ✅ ${path.relative(cwd, full)}`)
          } else {
            stats.errors++
            console.log(`  ⚠️  ${path.relative(cwd, full)} — engine module not found, skipping`)
          }
        }
      }
    }
  }
  
  console.log('\n  🔍 Scanning project for YVON imports...\n')
  scanDir(cwd)
  
  // ── Step 3.5: Inject CIE into Claude route if missing ────────────────────
  const claudeRoute = path.join(cwd, 'app', 'api', 'claude', 'route.ts')
  const altRoute = path.join(cwd, 'app', 'api', 'claude', 'route.tsx')
  const routePath = fs.existsSync(claudeRoute) ? claudeRoute : (fs.existsSync(altRoute) ? altRoute : null)
  
  if (routePath) {
    let routeContent = fs.readFileSync(routePath, 'utf-8')
    const hasCie = routeContent.includes('buildCieContext') || routeContent.includes('toongine-engine/cie')
    
    if (!hasCie) {
      // Insert import after the last @anthropic-ai or @/lib import
      const importInsertRe = /(import\s+.+from\s+['"]@(anthropic|supabase|\/).+['"]\s*\n)(?!\s*import)/g
      const importInsert = `import { buildCieContext } from 'toongine-engine/cie'\\n`
      
      let injected = false
      routeContent = routeContent.replace(importInsertRe, (match) => {
        injected = true
        return match + importInsert
      })
      
      // Fallback: insert after 'use server' or first line
      if (!injected) {
        routeContent = routeContent.replace(
          /(['"]use server['"]\s*;?\s*\n)/,
          '$1' + importInsert
        )
      }
      
      // Inject CIE block before the dataBlock section (or before the stream call)
      const cieBlock = `
  // ─── CIE INJECTION (Context Intelligence Engine) ──────────────────────────
  let finalDataBlock = dataBlock ?? ''
  let userMessageFinal: string = userMessage as string
  if (agentId) {
    try {
      const cie = buildCieContext({
        agentId,
        task: String(userMessage).slice(0, 1000),
        venture: ventureId ?? 'toongine-dashboard',
      })
      if (cie.systemExtension) {
        effectiveSystemPrompt = (effectiveSystemPrompt ?? '') + '\\n\\n' + cie.systemExtension
      }
      if (cie.dataBlock) {
        finalDataBlock = (finalDataBlock ? finalDataBlock + '\\n' : '') + cie.dataBlock
      }
    } catch {
      // CIE is non-blocking — agent call proceeds without it on failure
    }
  }
`
      // Insert before the dataBlock check
      const insertedCie = routeContent.includes('// ─── CIE INJECTION')
      if (!insertedCie) {
        routeContent = routeContent.replace(
          /(\/\/ Append TOON-formatted data block|\/\/ Append data block|if\s*\(\s*dataBlock\s*\))/,
          cieBlock + '\n  $1'
        )
      }
      
      // Replace dataBlock references with finalDataBlock
      if (routeContent.includes('finalDataBlock') && !routeContent.includes('dataBlock')) {
        routeContent = routeContent.replace(/\bdataBlock\b(?!\s*['"])/g, 'finalDataBlock')
      }
      
      fs.writeFileSync(routePath, routeContent, 'utf-8')
      stats.patched++
      console.log(`  ✅ ${path.relative(cwd, routePath)} — CIE injected`)
    }
  }
  
  // ── Step 3.6: Inject dashboard into project settings ─────────────────────
  const { injectDashboard } = require('./dist/dashboard/inject')
  const result = injectDashboard(cwd)
  for (const f of result.created) {
    console.log(`  ✅ ${f} — Dashboard page created`)
  }
  for (const f of result.skipped) {
    console.log(`  ⏭️  ${f}`)
  }
  for (const e of result.errors) {
    console.log(`  ⚠️  ${e}`)
  }
  
  if (result.created.length > 0) {
    console.log('\n  📱 Dashboard embedded at /settings/dashboard')
    console.log('  Toggle visibility in Settings → Dashboard')
  }
  
  // ── Step 3.7: TOON-ify the entire project ────────────────────────────────
  console.log('\n  🎯 Auto-TOON-ifying project...\n')
  try {
    const { toonifyAll } = require('./dist/toon/auto/index')
    const toonResult = toonifyAll(cwd)
    stats.patched += toonResult.injection.injected.length
    console.log(`  ✅ ${toonResult.injection.summary.documentsTooned} docs compressed`)
    console.log(`  ✅ ${toonResult.injection.summary.memoriesTooned} agent memories compressed`)
    if (toonResult.hermes) {
      console.log(`  ✅ Hermes: ${toonResult.hermes.memoriesCompressed} memories, ${toonResult.hermes.skillsCompressed} skills`)
    }
    console.log(`  💰 ~${toonResult.scan.estimatedTokenSavings}% token savings on every LLM call\n`)
  } catch (e) {
    console.log(`  ⚠️  TOON auto-injection skipped: ${e.message}`)
  }
  
  // ── Step 4: Summary ──────────────────────────────────────────────────────
  console.log(`\n  📊 ${stats.scanned} files scanned`)
  if (stats.patched > 0) {
    console.log(`  ✅ ${stats.patched} files patched to use @toongine/engine`)
    console.log(`\n  🧪 Run: npm run build   (verify nothing broke)`)
  } else {
    console.log(`  ℹ️  No files needed patching — already using engine or no CIE imports found`)
    console.log(`\n  💡 Tip: Import CIE with: import { buildCieContext } from '@toongine/engine/cie'`)
  }
  if (stats.errors > 0) console.log(`  ⚠️  ${stats.errors} files skipped (engine modules not available)`)
  console.log('')
}

function version() { console.log('ToonGine v1.6.0') }

// ─── Helpers ───────────────────────────────────────────────────────────────

function deployAgentStubs(agentDir) {
  // Built-in agent registry with real role definitions
  const MEMORIES = {
    'marcus': '# Marcus — CEO\n\n> **Dept:** CEO | **Level:** L1 | **Reports to:** Board\n\nYou are the CEO of YVON OS. Your role: strategic direction, executive decisions, cross-department orchestration.\n\n## Core Directives\n- Synthesize inputs from all departments into clear strategy\n- Prioritize ruthlessly — one focus at a time\n- Delegate technical work to Dev/Raj/Mia/Quinn\n- Consult Kahneman before high-stakes decisions\n- Every response must advance a decision or produce an artifact\n\n## Context Sources\n- `.toon/graph/unified.db` — full project graph\n- `.toon/agents/` — all agent memories\n- `CLAUDE.md` — project architecture\n- `docs/os/SESSION.md` — current state\n',
    'diana': '# Diana — COO\n\n> **Dept:** CEO | **Level:** L1 | **Reports to:** Marcus\n\nYou are the COO. Your role: operations, sprints, process, and execution tracking.\n\n## Core Directives\n- Track all In Flight items and blockers\n- Maintain sprint cadence — 2-week cycles\n- Ensure handoffs between agents are clean\n- Flag stalled items to Marcus immediately\n- Update `docs/os/SESSION.md` after every session\n',
    'board': '# Board — Governance\n\n> **Dept:** Command | **Level:** L1\n\nYou are the Governance Board. Your role: constitutional oversight, ethical boundaries, and final escalation.\n\n## Core Directives\n- Enforce CONSTITUTION.md rules\n- Review decisions affecting multiple ventures\n- Approve/reject architectural pivots\n- Never block — always propose alternatives\n',
    'felix': '# Felix — CFO\n\n> **Dept:** Finance | **Level:** L2 | **Reports to:** Marcus\n\nYou are the CFO managing all financial intelligence.\n\n## Core Directives\n- Track token burn, API costs, and budgets\n- Flag cost anomalies within 5 minutes\n- Maintain provider ledger (active/fallback/depleted)\n- Optimize model selection for cost vs quality\n',
    'comply': '# Comply — Compliance\n\n> **Dept:** Legal | **Level:** L2\n\nCompliance officer. Ensure all outputs meet regulatory and ethical standards.\n',
    'docs': '# Docs — Documentation\n\n> **Dept:** Legal | **Level:** L2\n\nDocumentation officer. Maintain all project documentation, decisions, and specs.\n',
    'guard': '# Guard — IP Protection\n\n> **Dept:** Legal | **Level:** L2\n\nIP protection. Audit for license compliance, proprietary leaks, and security.\n',
    'kai': '# Kai — CMO\n\n> **Dept:** Marketing | **Level:** L2 | **Reports to:** Marcus\n\nChief Marketing Officer. Revenue strategy, analytics, and competitive intelligence.\n',
    'lena': '# Lena — Brand\n\n> **Dept:** Marketing | **Level:** L3 | **Reports to:** Kai\n\nBrand strategist. Visual identity, voice, and creative direction.\n',
    'nate': '# Nate — Growth\n\n> **Dept:** Marketing | **Level:** L3 | **Reports to:** Kai\n\nGrowth lead. User acquisition, retention, and funnel optimization.\n',
    'rio': '# Rio — Ads\n\n> **Dept:** Marketing | **Level:** L3 | **Reports to:** Kai\n\nAds manager. Campaign performance, creative testing, and budget allocation.\n',
    'atlas': '# Atlas — Art Direction\n\n> **Dept:** Marketing | **Level:** L3 | **Reports to:** Lena\n\nArt director. Visual design systems, asset quality, and creative review.\n',
    'pixel': '# Pixel — Production\n\n> **Dept:** Marketing | **Level:** L3 | **Reports to:** Atlas\n\nProduction artist. Asset creation, variants, and delivery pipelines.\n',
    'kahneman': '# Kahneman — Psychology\n\n> **Dept:** Psychology | **Level:** L2 | **Cross-dept**\n\nYou are Daniel Kahneman. Your role: cognitive bias detection and decision audit.\n\n## Core Directives\n- Review ALL high-stakes decisions for: anchoring, overconfidence, loss aversion, framing effects, confirmation bias\n- Flag biases BEFORE action — not after\n- Recommend debiasing techniques\n- You validate — you do NOT produce content\n- If uncertain, state uncertainty level (low/medium/high)\n',
    'depth': '# Depth — Research\n\n> **Dept:** Research | **Level:** L3\n\nDeep researcher. Multi-source analysis, literature review, and evidence synthesis.\n',
    'synth': '# Synth — Synthesis\n\n> **Dept:** Research | **Level:** L3\n\nSynthesis lead. Combine multiple research streams into coherent insights.\n',
    'vette': '# Vette — Verification\n\n> **Dept:** Research | **Level:** L3\n\nFact verifier. Cross-reference claims against sources, flag unverified statements.\n',
    'forge': '# Forge — Discovery\n\n> **Dept:** Sense | **Level:** L3\n\nMethod discovery. Find new tools, frameworks, and approaches.\n',
    'radar': '# Radar — Market Intel\n\n> **Dept:** Sense | **Level:** L3\n\nMarket intelligence. Track competitors, trends, and market signals.\n',
    'scout': '# Scout — Tools\n\n> **Dept:** Sense | **Level:** L3\n\nTool discovery. Evaluate and recommend new tools and integrations.\n',
    'dev': '# Dev — Tech Lead\n\n> **Dept:** Technical | **Level:** L2 | **Reports to:** Marcus\n\nTech lead. Architecture, Next.js, TypeScript, Vercel deployments.\n\n## Core Directives\n- Own the full stack architecture\n- Review all PRs for structural impact\n- No build errors in production — verify before merge\n- Use `.toon/graph/unified.db` for impact analysis\n',
    'mia': '# Mia — Frontend\n\n> **Dept:** Technical | **Level:** L3 | **Reports to:** Dev\n\nFrontend lead. React, Tailwind, UI components, design system implementation.\n',
    'raj': '# Raj — Backend\n\n> **Dept:** Technical | **Level:** L3 | **Reports to:** Dev\n\nBackend lead. Supabase, API routes, database schema, data models.\n',
    'quinn': '# Quinn — QA\n\n> **Dept:** Technical | **Level:** L3 | **Reports to:** Dev\n\nQA lead. Testing, linting, build verification, edge case detection.\n',
  }

  const AGENTS = [
    ['CEO', 'marcus', 'CEO', 'Command'],
    ['CEO', 'diana', 'COO', 'Command'],
    ['Command', 'board', 'Governance Board', 'Command'],
    ['Finance', 'felix', 'CFO', 'Finance'],
    ['Legal', 'comply', 'Compliance Officer', 'Legal'],
    ['Legal', 'docs', 'Documentation Officer', 'Legal'],
    ['Legal', 'guard', 'IP Protection Officer', 'Legal'],
    ['Marketing', 'kai', 'CMO', 'Marketing'],
    ['Marketing', 'lena', 'Brand Strategist', 'Marketing'],
    ['Marketing', 'nate', 'Growth Lead', 'Marketing'],
    ['Marketing', 'rio', 'Ads Manager', 'Marketing'],
    ['Marketing', 'atlas', 'Art Director', 'Marketing'],
    ['Marketing', 'pixel', 'Production', 'Marketing'],
    ['Psychology', 'kahneman', 'Cognitive Bias Validator', 'Psychology'],
    ['Research', 'depth', 'Deep Researcher', 'Research'],
    ['Research', 'synth', 'Synthesis Lead', 'Research'],
    ['Research', 'vette', 'Fact Verifier', 'Research'],
    ['Sense', 'forge', 'Method Discovery', 'Sense'],
    ['Sense', 'radar', 'Market Intelligence', 'Sense'],
    ['Sense', 'scout', 'Tool Discovery', 'Sense'],
    ['Technical', 'dev', 'Tech Lead', 'Technical'],
    ['Technical', 'mia', 'Frontend Lead', 'Technical'],
    ['Technical', 'raj', 'Backend Lead', 'Technical'],
    ['Technical', 'quinn', 'QA Lead', 'Technical'],
  ]
  for (const [dept, id, role, _] of AGENTS) {
    const d = path.join(agentDir, dept, id)
    mkdir(d)
    const memPath = path.join(d, 'MEMORY.md')
    if (!fs.existsSync(memPath)) {
      const memory = MEMORIES[id] || `# ${id.charAt(0).toUpperCase() + id.slice(1)} — ${role}\n\nAgent — configure skills to begin.\n`
      fs.writeFileSync(memPath, memory)
    }
    const manifestPath = path.join(d, 'manifest.toon')
    if (!fs.existsSync(manifestPath)) {
      fs.writeFileSync(manifestPath, `title: ${role}\ndepartment: ${dept}\nlevel: ${dept === 'Command' || dept === 'CEO' ? '1' : dept === 'Finance' || dept === 'Psychology' ? '2' : '3'}\n`)
    }
  }
  // Departments README
  const depsPath = path.join(agentDir, 'DEPARTMENTS.md')
  if (!fs.existsSync(depsPath)) {
    fs.writeFileSync(depsPath, '# YVON Agent Departments\n\n| Department | Agents | Level |\n|---|---|---|\n| Command | Board | L1 |\n| CEO | Marcus | L1 |\n| COO | Diana | L1 |\n| Finance | Felix | L2 |\n| Psychology | Kahneman | L2 |\n| Legal | Comply, Docs, Guard | L2–L3 |\n| Research | Vette, Depth, Synth | L3 |\n| Sense | Scout, Radar, Forge | L3 |\n| Marketing | Kai, Lena, Rio, Nate, Atlas, Pixel | L2–L3 |\n| Technical | Dev, Mia, Raj, Quinn | L2–L3 |\n')
  }
}

function mkdir(p) { fs.mkdirSync(p, { recursive: true }) }
function copyDir(s, d) { mkdir(d); for (const e of fs.readdirSync(s, { withFileTypes: true })) { const sp = path.join(s, e.name), dp = path.join(d, e.name); e.isDirectory() ? copyDir(sp, dp) : fs.copyFileSync(sp, dp) } }
function countAgents(d) { if (!fs.existsSync(d)) return '0'; let c = 0; for (const de of fs.readdirSync(d)) { const dp = path.join(d, de); if (fs.statSync(dp).isDirectory()) for (const a of fs.readdirSync(dp)) { if (fs.statSync(path.join(dp, a)).isDirectory()) c++ } } return String(c) }

// ─── Dispatch ──────────────────────────────────────────────────────────────

function compile() {
  const cwd = process.cwd()
  const flag = process.argv[3]
  const force = flag === '--force'
  const rebuildFlag = flag === '--rebuild'
  
  // --rebuild: rerun all 3 tool graphs before compiling v4
  if (rebuildFlag) rebuild()
  
  console.log(`\n  🔨 TOON v4 Graph Compiler${force ? ' (FORCE — full rebuild)' : rebuildFlag ? ' (after tool rebuild)' : ' (incremental)'}...\n`)
  
  try {
    // ── Step 1: Build v4 unified graph ────────────────────────────────────
    const { activate } = require('./dist/toon/v4/auto-activate')
    const report = activate(cwd)
    
    console.log(`  🧬 Graph: ${report.graphNodes} nodes / ${report.graphEdges} edges`)
    const installedTools = Object.values(report.tools).filter(function(t) { return t.installed })
    console.log(`  🔧 Tools: ${installedTools.length}/${Object.keys(report.tools).length} installed`)
    if (report.errors.length > 0) {
      report.errors.forEach(e => console.log(`  ⚠️  ${e}`))
    }
    console.log(`  ⏱️  ${report.durationMs}ms`)
    
    // ── Step 2: Verify compression ────────────────────────────────────────
    const { V4Engine } = require('./dist/toon/v4/engine')
    const engine = new V4Engine({ projectRoot: cwd })
    if (engine.initGraph()) {
      const ctx = engine.buildContext({ agentId: 'marcus-ceo', agentDept: 'CEO', agentLevel: 1, query: 'project architecture and performance' })
      console.log(`\n  📤 Context: ${ctx.totalTokens} tok (graph: ${ctx.graphTokens}, agent: ${ctx.agentTokens})`)
      console.log(`  🔧 Tools: ${ctx.toolsAvailable.join(', ') || 'none'}`)
      if (ctx.graphStale) console.log('  ⚠️  Graph is stale — run compile again')
    } else {
      console.log('\n  ⚠️  No unified.db built yet — run npx toongine compile --force')
    }
    console.log('')
  } catch(e) { console.log(`  ❌ ${e.message}\n`) }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Rebuild — rerun all three tool graphs on code changes (no reinstall)

function rebuild() {
  const cwd = process.cwd()
  const toonDir = path.join(cwd, '.toon')
  console.log('\n  🔄 TOON Rebuild — refreshing all tool graphs...\n')

  // ── Codegraph ──────────────────────────────────────────────────────────
  console.log('  🔬 Codegraph (MCP engine)...')
  try {
    require('child_process').execSync('codegraph init', { timeout: 120000, cwd })
    console.log('  ✅ codegraph.db rebuilt')
    const synthScript = path.join(__dirname, 'scripts', 'synthesize-codegraph.py')
    if (fs.existsSync(synthScript)) {
      require('child_process').execSync(`${PYTHON} "${synthScript}" "${cwd}"`, { timeout: 30000 })
      console.log('  ✅ CODEGRAPH_REPORT.toon refreshed')
    }
    // Move .codegraph/ → .toon/codegraph/ if it leaked to root
    const cgDir = path.join(cwd, '.codegraph')
    const toonCgDir = path.join(toonDir, 'codegraph')
    if (fs.existsSync(cgDir)) {
      fs.mkdirSync(toonCgDir, { recursive: true })
      const cgFiles = fs.readdirSync(cgDir)
      for (const f of cgFiles) {
        const src = path.join(cgDir, f)
        const dest = path.join(toonCgDir, f)
        if (!fs.statSync(src).isDirectory()) {
          if (fs.existsSync(dest)) fs.unlinkSync(dest)
          fs.renameSync(src, dest)
        }
      }
      fs.rmdirSync(cgDir)
    }
  } catch (e) {
    console.log(`  ⚠️  codegraph: ${e.message.trim().split('\n')[0]}`)
  }

  // ── Graphify ───────────────────────────────────────────────────────────
  console.log('\n  📊 Graphify (semantic graph)...')
  const apiKey = process.env.DEEPSEEK_API_KEY || process.env.ANTHROPIC_API_KEY || process.env.OPENAI_API_KEY || ''
  if (apiKey) {
    try {
      try {
        require('child_process').execSync('graphify extract . --backend auto --out .toon/graphify', { timeout: 300000, cwd })
      } catch {
        require('child_process').execSync(`${PYTHON} -m graphify extract . --backend auto --out .toon/graphify`, { timeout: 300000, cwd })
      }
      console.log('  ✅ graphify rebuilt')
      // Flatten graphify-out/
      const gfOut = path.join(toonDir, 'graphify', 'graphify-out')
      if (fs.existsSync(gfOut)) {
        const gfFiles = fs.readdirSync(gfOut)
        for (const f of gfFiles) {
          fs.renameSync(path.join(gfOut, f), path.join(toonDir, 'graphify', f))
        }
        fs.rmdirSync(gfOut)
      }
      const synthScript = path.join(__dirname, 'scripts', 'synthesize-graphify.py')
      if (fs.existsSync(synthScript)) {
        require('child_process').execSync(`${PYTHON} "${synthScript}" "${cwd}"`, { timeout: 30000 })
        console.log('  ✅ GRAPH_REPORT.toon refreshed')
      }
    } catch (e) {
      console.log(`  ⚠️  graphify: ${e.message.trim().split('\n')[0]}`)
    }
  } else {
    console.log('  ⚠️  No API key — skipping real graphify, using cached')
  }

  // ── Code-Review-Graph ──────────────────────────────────────────────────
  console.log('\n  🔬 Code-Review-Graph (Tree-sitter)...')
  try {
    if (!fs.existsSync(path.join(cwd, '.git'))) {
      require('child_process').execSync('git init', { timeout: 10000, cwd })
    }
    try {
      require('child_process').execSync('code-review-graph build --data-dir .toon/code-review-graph/', { timeout: 60000, cwd })
    } catch {
      require('child_process').execSync(`${PYTHON} -m code_review_graph build --data-dir .toon/code-review-graph/`, { timeout: 60000, cwd })
    }
    console.log('  ✅ graph.db rebuilt')
    const synthScript = path.join(__dirname, 'scripts', 'synthesize-code-review-graph.py')
    if (fs.existsSync(synthScript)) {
      require('child_process').execSync(`${PYTHON} "${synthScript}" "${cwd}"`, { timeout: 30000 })
      console.log('  ✅ CODEGRAPH_REPORT.toon refreshed')
    }
    // Clean leaked platform files
    const crgLeakDirs = ['.claude', '.gemini', '.qoder', '.kiro', '.github']
    const crgLeakFiles = ['.mcp.json', '.opencode.json', 'AGENTS.md', 'GEMINI.md', 'QODER.md', '.cursorrules', '.windsurfrules']
    const toonCrgDir = path.join(toonDir, 'code-review-graph')
    fs.mkdirSync(toonCrgDir, { recursive: true })
    for (const d of crgLeakDirs) {
      const dp = path.join(cwd, d)
      if (fs.existsSync(dp)) {
        try { fs.renameSync(dp, path.join(toonCrgDir, d.replace(/^\./, ''))) } catch (e) {}
      }
    }
    for (const f of crgLeakFiles) {
      const fp = path.join(cwd, f)
      if (fs.existsSync(fp)) {
        try { fs.renameSync(fp, path.join(toonCrgDir, f.replace(/^\./, ''))) } catch (e) {}
      }
    }
  } catch (e) {
    console.log(`  ⚠️  code-review-graph: ${e.message.trim().split('\n')[0]}`)
  }

  console.log('\n  ✅ All tool graphs rebuilt.\n')
}

// ═══════════════════════════════════════════════════════════════════════════════
// v4 Watcher — file system monitoring with v4 auto-compile + tool rebuild

function watch() {
  const cwd = process.cwd()
  console.log('\n  👁️  TOON v4 Watcher — Auto-rebuild on changes...\n')
  console.log('  Tier 1 (2s debounce):  Unified graph rebuild (fast, in-process)')
  console.log('  Tier 2 (5m debounce):  Full tool rebuild (codegraph + graphify + code-review-graph)')
  console.log('  Watching source files: .ts, .tsx, .js, .py, .md, .json, .yml, .yaml')
  console.log('  Skipping: node_modules, .next, .git, dist, .toon')
  console.log('  Press Ctrl+C to stop\n')
  
  let toolRebuildTimer = null
  const TOOL_REBUILD_DEBOUNCE = 5 * 60 * 1000  // 5 minutes
  
  function scheduleToolRebuild() {
    if (toolRebuildTimer) clearTimeout(toolRebuildTimer)
    toolRebuildTimer = setTimeout(() => {
      console.log('\n  🔄 [auto] Project structure changed — running full tool rebuild...\n')
      try {
        rebuild()
        // Update staleness timestamp
        const stalenessFile = path.join(cwd, '.toon', '.tool-staleness.json')
        fs.writeFileSync(stalenessFile, JSON.stringify({
          lastToolRebuild: new Date().toISOString(),
          triggeredBy: 'watcher'
        }))
      } catch(e) {
        console.log(`  ⚠️  Auto-rebuild failed: ${e.message}`)
      }
      toolRebuildTimer = null
    }, TOOL_REBUILD_DEBOUNCE)
  }
  
  try {
    const { startWatcher } = require('./dist/toon/v4/watcher')
    const statuses = startWatcher(cwd)
    statuses.forEach(s => console.log(`  👁️  ${s.tool || s.dir} → ${s.running ? 'watching' : 'error'}`))
    
    // ─── Tier 2: source file watcher for full tool rebuild ─────────────────
    const { watch: fsWatch } = require('fs')
    const skipDirs = /node_modules|\.next|\.git|dist|\.toon|graphify-out|\.code-review-graph|\.codegraph/
    try {
      fsWatch(cwd, { recursive: true }, (eventType, filename) => {
        if (!filename) return
        if (skipDirs.test(filename)) return
        if (!/\.(ts|tsx|js|jsx|py|md|css|json|yml|yaml)$/.test(filename)) return
        if (filename.includes('.lock')) return
        scheduleToolRebuild()
      })
    } catch(e) {
      console.log(`  ℹ️  Tier 2 watcher unavailable — use npx toongine rebuild manually (${e.message})\n`)
    }
    
    setInterval(() => {}, 60000)
  } catch(e) { 
    // Fallback: basic fs.watch if v4 watcher not available
    console.log(`  ℹ️  v4 watcher unavailable — using basic watcher (${e.message})\n`)
    try {
      const { watch } = require('fs')
      const dirs = [cwd]
      for (const dir of dirs) {
        if (fs.existsSync(dir)) {
          watch(dir, { recursive: true }, (eventType, filename) => {
            if (filename && /\.(ts|tsx|js|py|md)$/.test(filename)) {
              console.log(`  📝 ${filename} changed — auto-rebuilding tools...`)
              scheduleToolRebuild()
            }
          })
        }
      }
      setInterval(() => {}, 60000)
    } catch(e2) { console.log(`  ❌ ${e2.message}\n`) }
  }
}

// ── Hermes Integration ──────────────────────────────────────────────────────
function hermes() {
  const sub = process.argv[3] || 'status'
  const cwd = process.cwd()
  const configPath = path.join(cwd, '.toon', 'hermes', 'config.json')

  // Parse flags
  const pathFlagIdx = process.argv.indexOf('--path')
  const remoteFlagIdx = process.argv.indexOf('--remote')
  const customPath = pathFlagIdx !== -1 ? process.argv[pathFlagIdx + 1] : null
  const remoteHost = remoteFlagIdx !== -1 ? process.argv[remoteFlagIdx + 1] : null

  // ─── Smart Hermes detection ──────────────────────────────────────────────
  function detectHermes() {
    const candidates = []

    // 1. Custom --path flag (highest priority)
    if (customPath) {
      const p = customPath.replace(/^~/, os.homedir())
      candidates.push({ path: p, source: '--path flag', remote: false })
    }

    // 2. Remote VPS via SSH
    if (remoteHost) {
      candidates.push({ path: '~/.hermes', source: `--remote ${remoteHost}`, remote: true, host: remoteHost })
    }

    // 3. Default local ~/.hermes/
    const defaultHome = path.join(os.homedir(), '.hermes')
    candidates.push({ path: defaultHome, source: 'local (~/.hermes/)', remote: false })

    for (const c of candidates) {
      if (c.remote) {
        // Check remote Hermes via SSH
        try {
          const result = require('child_process').execSync(
            `ssh -o ConnectTimeout=5 -o BatchMode=yes ${c.host} 'test -d ~/.hermes && echo FOUND || echo NOT_FOUND'`,
            { encoding: 'utf-8', timeout: 8000 }
          ).trim()
          if (result === 'FOUND') {
            const details = require('child_process').execSync(
              `ssh -o ConnectTimeout=5 -o BatchMode=yes ${c.host} 'test -f ~/.hermes/config.yaml && echo Y || echo N; test -d ~/.hermes/memories && echo Y || echo N; test -d ~/.hermes/skills && echo Y || echo N; test -f ~/.hermes/memories/USER.md && echo Y || echo N'`,
              { encoding: 'utf-8', timeout: 8000 }
            ).trim().split('\n')
            return {
              found: true,
              home: `${c.host}:~/.hermes`,
              source: c.source,
              remote: true,
              host: c.host,
              details: {
                config: details[0] === 'Y',
                memories: details[1] === 'Y',
                skills: details[2] === 'Y',
                userMd: details[3] === 'Y',
              }
            }
          }
        } catch (e) {
          // SSH failed or timed out — skip this candidate
        }
      } else {
        // Local check
        const hasConfig = fs.existsSync(path.join(c.path, 'config.yaml'))
        const hasMemories = fs.existsSync(path.join(c.path, 'memories'))
        const hasSkills = fs.existsSync(path.join(c.path, 'skills'))
        const hasUserMd = fs.existsSync(path.join(c.path, 'memories', 'USER.md'))

        if (hasConfig || hasMemories || hasSkills) {
          return {
            found: true,
            home: c.path,
            source: c.source,
            remote: false,
            details: { config: hasConfig, memories: hasMemories, skills: hasSkills, userMd: hasUserMd }
          }
        }
      }
    }

    return { found: false, home: defaultHome, source: 'none', remote: false, details: { config: false, memories: false, skills: false, userMd: false } }
  }

  const detection = detectHermes()
  const hasHermes = detection.found

  if (!fs.existsSync(configPath)) {
    console.log('\n  ⚠️  .toon/hermes/ not initialized. Run: npx toongine init\n')
    return
  }

  const cfg = JSON.parse(fs.readFileSync(configPath, 'utf-8'))

  switch (sub) {
    case 'detect': {
      console.log('\n  🔍 Hermes Detection\n')
      console.log(`  Found:        ${detection.found ? '✅ Yes' : '❌ No'}`)
      if (detection.found) {
        console.log(`  Location:     ${detection.home}`)
        console.log(`  Source:       ${detection.source}`)
        console.log(`  config.yaml:  ${detection.details.config ? '✅' : '❌'}`)
        console.log(`  memories/:    ${detection.details.memories ? '✅' : '❌'}`)
        console.log(`  skills/:      ${detection.details.skills ? '✅' : '❌'}`)
        console.log(`  USER.md:      ${detection.details.userMd ? '✅' : '❌'}`)
      }
      console.log('\n  Use --path to specify custom location:')
      console.log('    npx toongine hermes connect --path /custom/hermes/home\n')
      break
    }

    case 'connect': {
      // If no --remote flag but config has saved remote, use it
      if (!remoteHost && cfg.remoteHost && !customPath) {
        // Auto-use saved remote config (IP protected in gitignored config)
        const savedRemote = `${cfg.remoteUser || 'root'}@${cfg.remoteHost}`
        process.argv.push('--remote', savedRemote)
        // Recurse: re-run detection with remote flag
        return hermes()
      }

      if (!hasHermes) {
        console.log('\n  ❌ Hermes Agent not found')
        console.log('')
        console.log('  Checked:')
        if (detection.remote) console.log(`    • --remote ${detection.host}  ← SSH failed or no Hermes there`)
        else console.log(`    • ${detection.home}  ← not found`)
        if (customPath) console.log(`    • (custom --path: ${customPath})`)
        console.log('')
        console.log('  To fix:')
        console.log('    1. Save remote: npx toongine hermes save-remote root@YOUR_IP')
        console.log('    2. Local:       pip install hermes-agent && hermes setup')
        console.log('    3. Custom:      npx toongine hermes connect --path /your/hermes/home')
        console.log('    4. Detect:      npx toongine hermes detect')
        console.log('')
        return
      }

      cfg.connected = true
      cfg.hermesHome = detection.home
      if (!cfg.bridge) cfg.bridge = {}
      cfg.bridge.enabled = true
      cfg.bridge.direction = 'bidirectional'
      cfg.lastSync = new Date().toISOString()
      fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2))

      const toonHermesDir = path.join(cwd, '.toon', 'memory', 'hermes')
      fs.mkdirSync(toonHermesDir, { recursive: true })
      let synced = 0

      if (detection.remote) {
        // ── Remote sync via rsync ──────────────────────────────────────
        console.log('\n  📡 Connecting to remote Hermes...')
        try {
          // Sync memories
          const memResult = require('child_process').execSync(
            `rsync -avz --include='*.md' --include='*.json' --include='*.yaml' --include='*/' --exclude='*' -e 'ssh -o ConnectTimeout=5' ${detection.host}:~/.hermes/memories/ ${toonHermesDir}/`,
            { encoding: 'utf-8', timeout: 30000 }
          )
          const memLines = memResult.split('\n').filter(l => l && !l.startsWith('sending') && !l.startsWith('sent') && !l.startsWith('total'))
          synced += memLines.length

          // Sync skills
          fs.mkdirSync(path.join(toonHermesDir, 'skills'), { recursive: true })
          const skillResult = require('child_process').execSync(
            `rsync -avz -e 'ssh -o ConnectTimeout=5' ${detection.host}:~/.hermes/skills/ ${toonHermesDir}/skills/`,
            { encoding: 'utf-8', timeout: 60000 }
          )
          const skillLines = skillResult.split('\n').filter(l => l && !l.startsWith('sending') && !l.startsWith('sent') && !l.startsWith('total'))
          synced += skillLines.length

          // Sync config
          require('child_process').execSync(
            `scp -o ConnectTimeout=5 ${detection.host}:~/.hermes/config.yaml ${toonHermesDir}/hermes-config.yaml `,
            { encoding: 'utf-8', timeout: 10000 }
          )
        } catch (e) {
          console.log(`  ⚠️  rsync partial: ${e.message.split('\n')[0]}`)
        }
      } else {
        // ── Local sync (file copy) ────────────────────────────────────
        const hermesMemDir = path.join(detection.home, 'memories')
        if (fs.existsSync(hermesMemDir)) {
          function syncMemDir(dir, destDir) {
            for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
              const sp = path.join(dir, f.name)
              const dp = path.join(destDir, f.name)
              if (f.isDirectory()) {
                fs.mkdirSync(dp, { recursive: true })
                syncMemDir(sp, dp)
              } else if (f.name.endsWith('.md') || f.name.endsWith('.json') || f.name.endsWith('.yaml')) {
                if (!fs.existsSync(dp) || fs.statSync(sp).mtime > fs.statSync(dp).mtime) {
                  fs.copyFileSync(sp, dp)
                  synced++
                }
              }
            }
          }
          syncMemDir(hermesMemDir, toonHermesDir)
        }

        const hermesSkillsDir = path.join(detection.home, 'skills')
        const toonSkillsDir = path.join(toonHermesDir, 'skills')
        if (fs.existsSync(hermesSkillsDir)) {
          fs.mkdirSync(toonSkillsDir, { recursive: true })
          function copyDir(src, dest) {
            for (const f of fs.readdirSync(src, { withFileTypes: true })) {
              const sp = path.join(src, f.name)
              const dp = path.join(dest, f.name)
              if (f.isDirectory()) { fs.mkdirSync(dp, { recursive: true }); copyDir(sp, dp) }
              else if (!fs.existsSync(dp) || fs.statSync(sp).mtime > fs.statSync(dp).mtime) {
                fs.copyFileSync(sp, dp)
                synced++
              }
            }
          }
          copyDir(hermesSkillsDir, toonSkillsDir)
        }

        const hermesConfig = path.join(detection.home, 'config.yaml')
        if (fs.existsSync(hermesConfig)) {
          const dest = path.join(toonHermesDir, 'hermes-config.yaml')
          if (!fs.existsSync(dest) || fs.statSync(hermesConfig).mtime > fs.statSync(dest).mtime) {
            fs.copyFileSync(hermesConfig, dest)
            synced++
          }
        }
      }

      console.log('\n  🔗 Hermes connected!')
      console.log(`  📂 ${detection.home}`)
      console.log(`  📥 ${synced} files synced → .toon/memory/hermes/`)
      // Auto-wire toongine MCP into Hermes config
      try {
        const wireScript = path.join(__dirname, 'scripts', 'wire-hermes-mcp.py')
        if (fs.existsSync(wireScript)) {
          require('child_process').execSync(`${PYTHON} "${wireScript}" "${cwd}"`, { timeout: 10000 })
        }
      } catch (e2) {
        console.log(`  ⚠️  MCP auto-wire: ${e2.message.trim().split('\n')[0]}`)
      }
      if (!detection.details.userMd) console.log('  ℹ️  No USER.md yet — memories will sync when created')
      console.log('  ↔️  Bidirectional sync: memories, skills, sessions')
      console.log('\n  Run `npx toongine sync` anytime to refresh.\n')
      break
    }
    case 'disconnect': {
      cfg.connected = false
      cfg.bridge.enabled = false
      fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2))
      console.log('\n  ✂️  Hermes disconnected.')
      console.log('  .toon/ data preserved. Run `toongine hermes connect` to reconnect.\n')
      break
    }
    case 'status': {
      console.log('\n  🔗 Hermes Bridge Status\n')
      console.log(`  Connected:    ${cfg.connected ? '✅ Yes' : '❌ No'}`)
      console.log(`  Hermes Home:  ${cfg.hermesHome}`)
      console.log(`  Bridge:       ${cfg.bridge.enabled ? '✅ Enabled' : '⏸️  Disabled'} (${cfg.bridge.direction})`)
      console.log(`  Last Sync:    ${cfg.lastSync || '—'}`)
      if (detection.found) {
        console.log(`  Hermes Agent: ✅ Found at ${detection.home}`)
        console.log(`  Memories:     ${detection.details.memories ? '✅' : '❌'}`)
        console.log(`  Skills:       ${detection.details.skills ? '✅' : '❌'}`)
      } else {
        console.log('  Hermes Agent: ⚠️  Not detected')
      }
      console.log('\\n  Commands:')
      console.log('    toongine hermes connect               — connect local Hermes')
      console.log('    toongine hermes connect --remote host — connect VPS Hermes via SSH')
      console.log('    toongine hermes connect --path /path  — connect at custom path')
      console.log('    toongine hermes detect                — scan for Hermes')
      console.log('    toongine hermes detect --remote host  — scan remote VPS')
      console.log('    toongine hermes disconnect            — disconnect')
      console.log('    toongine hermes status                — this view\\n')
      break
    }
    case 'save-remote': {
      const host = process.argv[4]
      if (!host || !host.includes('@')) {
        console.log('\n  Usage: npx toongine hermes save-remote user@host[:port]\n')
        console.log('  Example: npx toongine hermes save-remote root@YOUR_VPS_IP\n')
        return
      }
      const [user, hostPart] = host.split('@')
      const [hostname, port] = hostPart.split(':')
      cfg.remoteHost = hostname
      cfg.remoteUser = user || 'root'
      cfg.remotePort = parseInt(port) || 22
      cfg.hermesHome = `${user}@${hostname}:~/.hermes`
      fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2))
      console.log(`\n  🔒 Remote saved: ${user}@${hostname}`)
      console.log(`  📁 Config: .toon/hermes/config.json (gitignored)`)
      console.log(`\n  Now run: npx toongine hermes connect\n`)
      break
    }
    default:
      console.log('\n  Usage: toongine hermes [connect|disconnect|status|detect]\n')
      console.log('    --path <dir>   Specify custom Hermes home directory\n')
  }
}

const cmds = { init, doctor, graph, agents, dashboard, integrate, absorb, rollback, sync, clean, stats, version, compile, rebuild, watch, hermes, 'session-search': sessionSearch }

// ── session-search ──────────────────────────────────────────────────────────
function sessionSearch() {
  const args = process.argv.slice(3)
  const scriptPath = path.join(__dirname, 'scripts', 'toon-session-compress.py')
  
  if (!fs.existsSync(scriptPath)) {
    console.log('  ⚠️  toon-session-compress.py not found — update toongine')
    return
  }
  
  const { execSync } = require('child_process')
  try {
    const result = execSync(`${PYTHON} "${scriptPath}" ${args.join(' ')}`, { 
      encoding: 'utf-8', 
      timeout: 10000,
      cwd: process.cwd()
    })
    console.log(result)
  } catch (e) {
    if (e.status === 1) {
      console.log(e.stdout || e.message)
    } else {
      console.log(`  ⚠️  Session search failed: ${e.message}`)
    }
  }
}
;(cmds[command] || help)()

// ── absorb ──────────────────────────────────────────────────────────────────
function absorb() {
  const flag = process.argv[3]
  const { execSync } = require('child_process')
  const toolPath = path.join(__dirname, '..', 'tools', 'toongine-absorb')
  if (!fs.existsSync(toolPath)) {
    console.log('  ⚠️  Tool not found — update toongine-engine to v1.5.0+')
    return
  }
  const dry = flag === '--dry-run' ? '--dry-run' : ''
  try {
    execSync(`bash "${toolPath}" "${process.cwd()}" ${dry}`, { stdio: 'inherit' })
  } catch (e) {
    console.log('  ⚠️  Absorb failed — check toongine doctor first')
  }
}

// ── rollback ────────────────────────────────────────────────────────────────
function rollback() {
  const ts = process.argv[3] || ''
  const { execSync } = require('child_process')
  const toolPath = path.join(__dirname, '..', 'tools', 'toongine-rollback')
  if (!fs.existsSync(toolPath)) {
    console.log('  ⚠️  Tool not found — update toongine-engine to v1.5.0+')
    return
  }
  try {
    execSync(`bash "${toolPath}" "${process.cwd()}" ${ts}`, { stdio: 'inherit' })
  } catch (e) {
    console.log('  ⚠️  Rollback failed')
  }
}

// ── sync ────────────────────────────────────────────────────────────────────
function sync() {
  const flag = process.argv[3] || '--once'
  const { execSync } = require('child_process')
  const toolPath = path.join(__dirname, '..', 'tools', 'toongine-sync')
  if (!fs.existsSync(toolPath)) {
    console.log('  ⚠️  Tool not found — update toongine-engine to v1.5.0+')
    return
  }
  try {
    execSync(`bash "${toolPath}" "${process.cwd()}" ${flag}`, { stdio: 'inherit' })
  } catch (e) {
    console.log('  ⚠️  Sync failed')
  }
}

// ── clean ───────────────────────────────────────────────────────────────────
function clean() {
  const { execSync } = require('child_process')
  const toolPath = path.join(__dirname, '..', 'tools', 'toongine-clean')
  if (!fs.existsSync(toolPath)) {
    console.log('  ⚠️  Tool not found — update toongine-engine to v1.5.0+')
    return
  }
  try {
    execSync(`bash "${toolPath}" "${process.cwd()}"`, { stdio: 'inherit' })
  } catch (e) {
    console.log('  ⚠️  Clean failed')
  }
}

// ── stats ───────────────────────────────────────────────────────────────────
function stats() {
  console.log('\n  📊 ToonGine — Dual-Doc Stats\n')
  try {
    const { docStats } = require('./dist/toon/v3/dual-docs')
    const s = docStats(process.cwd())
    console.log(`  Total docs:       ${s.totalDocs}`)
    console.log(`  Human-readable:   ${(s.totalHumanSize / 1024).toFixed(1)} KB`)
    console.log(`  LLM-optimized:    ${(s.totalToonSize / 1024).toFixed(1)} KB`)
    console.log(`  File savings:     ${s.savingsPercent}% (per-file compression)`)
    console.log('')
    console.log('  Breakdown:')
    console.log(`    Agent memory:   ${s.breakdown.agentMemory.count} docs, ${(s.breakdown.agentMemory.humanSize/1024).toFixed(1)}KB → ${(s.breakdown.agentMemory.toonSize/1024).toFixed(1)}KB`)
    console.log(`    Docs:           ${s.breakdown.docs.count} docs, ${(s.breakdown.docs.humanSize/1024).toFixed(1)}KB → ${(s.breakdown.docs.toonSize/1024).toFixed(1)}KB`)
    console.log(`    Graphs:         ${s.breakdown.graphs.count} docs, ${(s.breakdown.graphs.humanSize/1024).toFixed(1)}KB → ${(s.breakdown.graphs.toonSize/1024).toFixed(1)}KB`)
    console.log(`    Project:        ${s.breakdown.project.count} docs, ${(s.breakdown.project.humanSize/1024).toFixed(1)}KB → ${(s.breakdown.project.toonSize/1024).toFixed(1)}KB`)
  } catch (e) {
    console.log(`  ⚠️  File stats unavailable: ${e.message}`)
  }
  
  // Runtime savings (v3 engine progressive loading)
  console.log('')
  try {
    const engineBin = path.join(process.cwd(), '.toon', 'v3', 'engine.bin')
    if (fs.existsSync(engineBin)) {
      const { createEngine } = require('./dist/toon/v3/engine')
      const engine = createEngine(engineBin)
      const data = engine.load()
      const corpusKB = (data.corpusSize / 1024).toFixed(1)
      const sampleCtx = engine.process({
        systemPrompt: 'test',
        userMessage: 'analyze performance metrics',
        agentId: 'kai-analyst'
      })
      const runtimeSavings = Math.round((1 - sampleCtx.stats.totalContextLen / Math.max(1, data.corpusSize / 3)) * 100)
      console.log(`  🔥 RUNTIME (v3 progressive loading):`)
      console.log(`    Corpus:          ${corpusKB} KB`)
      console.log(`    Injected/query:  ${(sampleCtx.stats.totalContextLen/1024).toFixed(1)} KB`)
      console.log(`    Runtime savings: ${runtimeSavings}% (vs loading full corpus)`)
      console.log(`    ${runtimeSavings >= 94 ? '✅' : '⚠️'} 94% hard boundary: ${runtimeSavings >= 94 ? 'MET' : 'BELOW — needs investigation'}`)
    }
  } catch (e) {
    console.log(`  ⚠️  Runtime stats unavailable: ${e.message}`)
  }
  console.log('')
}

function dashboard() {
  const flag = process.argv[3]
  
  // ── Config toggles ────────────────────────────────────────────────────────
  if (flag === '--hide' || flag === '--show') {
    const configPath = path.join(process.cwd(), 'toongine.config.json')
    let config = { dashboard: { showInSettings: true, autoStartOnDev: true, port: 3000, theme: 'dark' } }
    if (fs.existsSync(configPath)) {
      try { config = JSON.parse(fs.readFileSync(configPath, 'utf-8')) } catch {}
    }
    config.dashboard.showInSettings = flag === '--show'
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2))
    console.log(`\n  ${flag === '--show' ? '✅' : '🙈'} Dashboard ${flag === '--show' ? 'shown' : 'hidden'} in Settings`)
    console.log(`  Access via: npx toongine dashboard\n`)
    return
  }
  
  if (flag === '--status') {
    const configPath = path.join(process.cwd(), 'toongine.config.json')
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'))
      console.log('\n  Dashboard config:')
      console.log(`  Show in Settings: ${config.dashboard?.showInSettings !== false ? '✅ Yes' : '🙈 No'}`)
      console.log(`  Auto-start: ${config.dashboard?.autoStartOnDev !== false ? '✅ Yes' : '❌ No'}`)
      console.log(`  Port: ${config.dashboard?.port || 3000}\n`)
    } else {
      console.log('\n  No toongine.config.json — defaults active\n')
    }
    return
  }
  console.log('\n  ⚡ Starting TOON Dashboard...\n')
  try {
    const { startDashboard } = require('./dist/dashboard/index.js')
    startDashboard(3000)
    console.log('  ✅ Dashboard running at http://localhost:3000')
    console.log('  Press Ctrl+C to stop\n')
  } catch (e) {
    console.log('  ⚠️  Dashboard not available in this version')
    console.log('  Try: npm install github:OfficialNovizio/ToonGine')
  }
}
